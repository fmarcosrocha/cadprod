# APP Javascript ORIENTADO A OBJETOS CADASTRO DE PRODUTOS 

![](docs/screenshot.png)
